"""XML Chunker module."""
from .xml_chunker import XMLChunker, iter_chunks_from_xml

__all__ = ["XMLChunker", "iter_chunks_from_xml"]
